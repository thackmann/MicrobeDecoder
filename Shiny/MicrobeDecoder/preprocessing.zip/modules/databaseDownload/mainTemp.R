# Define the Database Download Module in Shiny App
# This script defines the user interface (UI) and server for the database download module
# Author: Timothy Hackmann
# Date: 18 February 2025

# === Define user interface (UI) ===
  databaseDownloadUI <- function(id) {
    ns <- shiny::NS(id)
    shiny::tagList(
      shiny::fluidRow(
        shiny::column(width = 2),
        shiny::column(
          create_title_div("Download database"),
          p(""),
          p(""),
          p(h5("Download the database in csv format.")),
          create_download_button(ns('download_clean_database'), label = "Download"),
          p(""),
          p(""),
          p(h5("Download the unprocessed (raw) database in csv format.")),
          create_download_button(ns('download_raw_database'), label = "Download"),
          width = 8
        ),
        shiny::column(width = 2)
      )
    )
  }
  
# === Define server ===
  databaseDownloadServer <- function(id) {
    shiny::moduleServer(id, function(input, output, session) {
    # --- Generate outputs ---
    # Output downloadable csv of the clean database
    output$download_clean_database <- create_download_handler(
      filename_prefix = "database",
      data_source = function() {
        load_database() |>
          dplyr::select(-dplyr::ends_with("link"))
      }
    )
    
    # Output downloadable csv of the raw database
    output$download_raw_database <- create_download_handler(
      filename_prefix = "database_raw",
      data_source = function() {
        load_database("raw")
      }
    )
      })
  }
