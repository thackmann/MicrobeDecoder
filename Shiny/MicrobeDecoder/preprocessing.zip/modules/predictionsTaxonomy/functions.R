# Define Functions for Predictions from Taxonomy Module
# These are functions specific to this module
# Author: Timothy Hackmann
# Date: 20 May 2026

# === Getting inputs ===
  #' Get Query Taxa
  #'
  #' Processes the query taxa input from either a database selection or uploaded file.
  #'
  #' @param taxonomy_from_database Logical. Use database input?
  #' @param taxonomy_from_upload Logical. Use uploaded file?
  #' @param selected_organisms A character vector of selected taxa (if from database).
  #' @param taxonomy_upload_path File path to uploaded taxonomy file.
  #' @param system_taxonomy A character string giving the taxonomy system (e.g. `"LPSN"`). Default is `"LPSN"`. If `NULL` or invalid, falls back to `"LPSN"`.
  #' @return A processed \code{query_taxa} data frame.
  get_query_taxa <- function(taxonomy_from_database,
                             taxonomy_from_upload,
                             selected_organisms = NULL,
                             taxonomy_upload_path = NULL,
                             system_taxonomy = "LPSN") {
    if (taxonomy_from_database) {
      query_taxa <- get_query_taxa_from_database(selected_organisms = selected_organisms, system_taxonomy = system_taxonomy)
      run_validation_modal(need(!is.null(query_taxa) && nrow(query_taxa) > 0, "Please choose a taxon"))
    } else if (taxonomy_from_upload) {
      query_taxa <- get_query_taxa_from_upload(upload_path = taxonomy_upload_path)
      
      run_validation_modal(need(!is.null(query_taxa) && nrow(query_taxa) > 0, "Please check the format of the taxonomy file and try again."))
    } else {
      stop("No valid taxonomy input specified.")
    }
    
    return(query_taxa)
  }
  
  #' Get Traits Input
  #'
  #' Validates trait inputs and processes query string for custom traits.
  #'
  #' @param traits_from_standard Logical. Is this a standard trait?
  #' @param traits_from_other Logical. Is this a custom trait?
  #' @param traits_to_predict A character vector of trait categories to predict.
  #' @param query_string A character string representing the query used to filter the organisms.
  #' @return A named list with \code{traits_to_predict} and \code{query_string}.
  get_traits_input <- function(traits_from_standard,
                               traits_from_other,
                               traits_to_predict = NULL,
                               query_string = NULL) {
    if (traits_from_standard) {
      run_validation_modal(need(!is.null(traits_to_predict) && length(traits_to_predict) > 0, "Please choose a trait"))
      return(list(traits_to_predict = traits_to_predict, query_string = NULL))
    } else if (traits_from_other) {
      query_string <- get_query_string(query_string)
      return(list(traits_to_predict = "Custom trait", query_string = query_string))
    } else {
      stop("No valid trait source specified.")
    }
  }
  
  #' Get Inputs for Taxonomy Module
  #'
  #' This is the main function for getting all inputs for the module
  #'
  #' @param taxonomy_from_database Logical. Whether taxonomy is selected from database.
  #' @param taxonomy_from_upload Logical. Whether taxonomy is uploaded from a file.
  #' @param traits_from_standard Logical. Whether traits are standard.
  #' @param traits_from_other Logical. Whether trait is defined by a custom query.
  #' @param selected_organisms A character vector of selected taxa (if from database).
  #' @param taxonomy_upload_path File path to uploaded taxonomy file.
  #' @param traits_to_predict A character vector of trait categories to predict.
  #' @param query_string A character string representing the query used to filter the organisms.
  #' @param metadata_upload A Shiny file upload object containing organism metadata, or NULL.
  #' @param hide_poor_traits Logical; whether to hide poorly predicted traits.
  #' @param ignore_NA Logical; whether to ignore `NA` values. Default is `TRUE`.
  #' @param match_all_ranks Logical; if TRUE, all ranks must match. Default is FALSE.
  #' @param ignore_species Logical; whether to ignore the rank of species in taxa.
  #' @param system_taxonomy A character string giving the taxonomy system (e.g. `"LPSN"`). Default is `"LPSN"`. If `NULL` or invalid, falls back to `"LPSN"`.
  #' @return A named list of inputs for downstream processing.
  get_taxonomy_inputs <- function(
      taxonomy_from_database,
      taxonomy_from_upload,
      traits_from_standard,
      traits_from_other,
      selected_organisms = NULL,
      taxonomy_upload_path = NULL,
      traits_to_predict = NULL,
      query_string = NULL,
      metadata_upload = NULL,
      hide_poor_traits,
      ignore_NA,
      match_all_ranks,
      ignore_species,
      system_taxonomy
  ) {
    query_taxa <- get_query_taxa(
      taxonomy_from_database = taxonomy_from_database,
      taxonomy_from_upload = taxonomy_from_upload,
      selected_organisms = selected_organisms,
      taxonomy_upload_path = taxonomy_upload_path,
      system_taxonomy = system_taxonomy
    )
    
    traits_info <- get_traits_input(
      traits_from_standard = traits_from_standard,
      traits_from_other = traits_from_other,
      traits_to_predict = traits_to_predict,
      query_string = query_string
    )
    
    metadata <- get_metadata_from_upload(
      metadata_upload = metadata_upload
    )
    
    list(
      query_taxa = query_taxa,
      traits_to_predict = traits_info$traits_to_predict,
      metadata = metadata,
      query_string = traits_info$query_string,
      hide_poor_traits = hide_poor_traits,
      ignore_NA = ignore_NA,
      match_all_ranks = match_all_ranks,
      ignore_species = ignore_species,
      system_taxonomy = system_taxonomy
    )
  }

# === Computing results ===
  #' Extract Unique Values from a Delimited Vector
  #'
  #' This function takes a character vector where each element may contain 
  #' multiple values separated by a specified delimiter. It extracts and 
  #' returns a unique list of all values.
  #'
  #' @param x A vector with delimited values (will be coerced to character if needed).
  #' @param delimiter A string indicating the delimiter used to separate values. Default is `";"`.
  #' @return A character vector of unique values sorted alphabetically, or NULL if coercion fails.
  #' @examples
  #' vec <- c("lactate", "acetate;ethanol;H2;CO2", "acetate;butyrate", "acetate", NA)
  #' extract_unique_values(vec)
  #' extract_unique_values(vec, delimiter = ",")
  #' @export
  extract_unique_values <- function(x, delimiter = ";") {
    if (!is.character(x)) {
      x <- tryCatch(as.character(x), error = function(e) NULL)
      
      if (is.null(x)) {
        warning("Unable to coerce input to character. Returning NULL.")
        return(NULL)
      }
    }
    
    unique_values <- unique(unlist(strsplit(na.omit(x), delimiter)))
    sorted_values <- sort(unique_values)
    
    return(sorted_values)
  }
  
  #' Convert a Query into a Regular Expression for Matching
  #'
  #' This function converts a query string into a regular expression for matching,
  #' padding strings with "^" and "$" to prevent partial matches.
  #'
  #' @param x A character string or `NA` value to be formatted.
  #' @return A formatted regular expression string.
  #' @export
  format_query_element <- function(x) {
    return(paste0("^", x, "$"))
  }
  
  #' Print Matching Organism Names to Console
  #'
  #' This helper function prints the query taxon and matching organisms (Phylum
  #' through Species) to the R console as formatted tables. It is called within
  #' \code{filter_table_by_taxon} when \code{print_matches = TRUE}.
  #'
  #' @param match A data frame of matched rows from the reference table, containing some or all of the columns Phylum, Class, Order, Family, Genus, Species.
  #' @param query_taxa_regex A one-row data frame of taxonomic rank columns (Phylum, Class, Order, Family, Genus, Species) with regex pattern values (e.g. \code{"^Escherichia$"}), representing a single formatted query from \code{get_query_taxa_regex}.
  #' @param query_number An optional integer indicating the query index, printed
  #'   as a header when multiple queries are present. Default is NULL (no header).
  #'
  #' @return NULL (invisibly). Called for its side effect of printing to the console.
  #' @export
  print_match_names <- function(match, query_taxa_regex, query_number = NULL) {
    rank_cols <- c("Phylum", "Class", "Order", "Family", "Genus", "Species")
    
    # Print query number header if provided
    if (!is.null(query_number)) {
      cat(sprintf("--- Query %d ---\n", query_number))
    }
    
    # Print query as a table, stripping regex anchors and dropping NA columns
    query_display <- as.data.frame(
      lapply(query_taxa_regex, function(x) gsub("\\^|\\$", "", x)),
      stringsAsFactors = FALSE
    )
    query_display <- query_display[, !sapply(query_display, function(x) is.na(x) | x == "NA"),
                                   drop = FALSE]
    cat("Query:\n")
    print(query_display, row.names = FALSE)
    
    # Print matches as a table
    tax_cols <- intersect(rank_cols, colnames(match))
    if (nrow(match) > 0 && length(tax_cols) > 0) {
      cat("Matches:\n")
      tax_df <- match[, tax_cols, drop = FALSE]
      rownames(tax_df) <- seq_len(nrow(tax_df))
      print(tax_df)
    } else {
      cat("Matches: none\n")
    }
    
    invisible(NULL)
  }
  
  #' Get Reference Table of Organisms
  #'
  #' This function takes the database and formats into a reference table of organisms
  #' and their traits.  It can optionally add a custom trait based on a query string.
  #'
  #' Returns the full taxonomy universe (every organism) with the requested trait
  #' columns attached.  NA filtering is intentionally not applied here: taxon
  #' lookup is decoupled from trait availability so that taxa with no annotated
  #' traits remain matchable.  Downstream code (\code{\link{compute_probabilities}})
  #' handles per-trait NA semantics via its own \code{ignore_NA} argument.
  #'
  #' @param data A data frame of the database.
  #' @param system_taxonomy A character string giving the taxonomy system (e.g. `"LPSN"`). Default is `"LPSN"`. If `NULL` or invalid, falls back to `"LPSN"`.
  #' @param traits_to_predict A character vector of trait categories to predict.
  #' @param query_string A character string representing the query used to filter the organisms.
  #' @return A reference table of organisms and their traits
  #' @export
  get_reference_table <- function(data,
                                  system_taxonomy = "LPSN",
                                  traits_to_predict = NULL,
                                  query_string = NULL) {
    # Get data
    table <- data
    
    # Add taxonomy
    col_name <- paste0(system_taxonomy, " Taxonomy")
    table <- expand_and_merge_taxonomy(data = table, col_name = col_name)
    
    # Add custom traits
    if(!is.null(query_string)) {
      trait_name <- "Custom trait"
      table <- add_custom_traits(data = table, query_string = query_string, trait_name = trait_name)
      traits_to_predict <- trait_name
    }
    
    # Select relevant columns
    table <- table |>
      dplyr::select(Phylum, Class, Order, Family, Genus, Species, dplyr::all_of(traits_to_predict))
    
    return(table)
  }
  
  #' Filter a Table by Taxon
  #'
  #' This function filters a table to return rows matching a specified query taxon.
  #' It starts at the most specific level (Genus + Species) and progressively moves up
  #' the taxonomic ranks until a match is found. There is an option to require
  #' all ranks to match (strict mode). Ranks that are NA (^NA$) are ignored.
  #'
  #' @param table A data frame to be filtered.
  #' @param query_taxa_regex A one-row data frame of taxonomic rank columns (Phylum, Class, Order, Family, Genus, Species) with regex pattern values (e.g. \code{"^Escherichia$"}), representing a single formatted query from \code{get_query_taxa_regex}.
  #' @param ignore_species Logical; whether to ignore the rank of species in taxa.
  #' @param match_all_ranks Logical; if TRUE, all ranks must match. Default is FALSE.
  #' @param print_matches Logical; if TRUE, prints matching organisms (Phylum through
  #'   Species) to the R console via \code{\link{print_match_names}}. Default is TRUE.
  #' @param query_number An optional integer indicating the query index, passed to
  #'   \code{\link{print_match_names}} for display when multiple queries are present.
  #'   Default is NULL (no header printed).
  #'
  #' @return A filtered data frame containing only rows that match the query taxon.
  #' @export
  filter_table_by_taxon <- function(table, query_taxa_regex, ignore_species = TRUE,
                                    match_all_ranks = FALSE, print_matches = FALSE,
                                    query_number = NULL) {
    # Set levels of taxonomic ranks to match
    rank_levels <- list(
      c("Genus", "Species"),
      "Genus",
      "Family",
      "Order",
      "Class",
      "Phylum"
    )
    
    if (ignore_species) {
      rank_levels <- lapply(rank_levels, setdiff, "Species")
    }
    
    valid_levels <- names(query_taxa_regex)[
      names(query_taxa_regex) %in% unlist(rank_levels) & !sapply(query_taxa_regex, identical, "^NA$")
    ]
    
    rank_levels <- lapply(rank_levels, function(ranks) {
      intersect(ranks, valid_levels)
    })
    
    rank_levels <- Filter(length, rank_levels)
    rank_levels <- rank_levels[!duplicated(rank_levels)]
    
    # Option 1 (strict): match across all taxonomic ranks at once
    if (match_all_ranks) {
      match <- table
      
      all_ranks_to_match <- unique(unlist(rank_levels))
      
      for (rank in all_ranks_to_match) {
        pattern <- query_taxa_regex[[rank]]
        if (!identical(pattern, "^.*$")) {
          match <- dplyr::filter(match, grepl(pattern, .data[[rank]]))
        }
      }
      
      if (print_matches) print_match_names(match, query_taxa_regex, query_number)
      
      match <- as.data.frame(match)
      
      return(match)
    }
    
    # Option 2 (permissive): start matching at low taxonomic levels, then move up if no match
    for (ranks in rank_levels) {
      match <- table
      for (rank in ranks) {
        pattern <- query_taxa_regex[[rank]]
        if (!identical(pattern, "^.*$")) {
          match <- dplyr::filter(match, grepl(pattern, .data[[rank]]))
        }
      }
      if (nrow(match) > 0) {
        if (print_matches) print_match_names(match, query_taxa_regex, query_number)
        match <- as.data.frame(match)
        
        return(match)
      }
    }
    
    # No match found at any level
    if (print_matches) print_match_names(table[0, ], query_taxa_regex, query_number)
    match <- as.data.frame(table[0, ])
    
    return(match)
  }
  
  #' Convert a Trait into a Regular Expression for Matching
  #'
  #' This function converts a trait string into a regular expression for matching,
  #' padding strings with "(?<=^|;)" and "(?=;|$)" to prevent partial matches. 
  #' Specifically, it will match traits at the start of string, end of a string, 
  #' and those containing ";".
  #'
  #' @param x A character string or `NA` value to be formatted.
  #' @return A formatted regular expression string.
  #' @export
  format_trait_element <- function(x) {
    return(paste0("(?<=^|;)", x, "(?=;|$)"))
  }
  
  #' Calculate the Fraction of Matching Elements in a Vector
  #'
  #' This function calculates the fraction of elements in a character vector that match 
  #' a given regular expression, with options to ignore NA values or replace them with 
  #' a specified value.
  #'
  #' @param x A character vector.
  #' @param pattern A regular expression pattern to match within elements of `x`.
  #' @param ignore_NA Logical; whether to ignore `NA` values (`TRUE`, default) or replace them with `replace_value` (`FALSE`).
  #' @param replace_value A numeric value used to replace NA values when `ignore_NA = FALSE`. 
  #'        Default is 0.
  #'
  #' @return The fraction of elements in `x` that match the pattern.
  #' @examples
  #' vec <- c("acetate", "butyrate;acetate", "acetate;propionate", "butyrate", NA)
  #' match_fraction(vec, pattern = "(?<=^|;)acetate(?=;|$)")  # Default: ignores NA
  #' match_fraction(vec, pattern = "(?<=^|;)acetate(?=;|$)", ignore_NA = FALSE, replace_value = 0)
  #'
  #' @export
  match_fraction <- function(x, pattern, ignore_NA = TRUE, replace_value = 0) {
    if (is.null(x) || length(x) == 0 || all(is.na(x))) {
      return(0)  # Return 0 for empty, NULL, or all-NA cases
    }
    
    if (!is.character(x)) {
      x <- tryCatch(as.character(x), error = function(e) NULL)
      if (is.null(x)) {
        warning("Unable to coerce input to character. Returning 0.")
        return(0)
      }
    }
    
    # Convert matches into binary (0 or 1). grepl is vectorized and far faster
    # than gregexpr + sapply, which finds every match position only to test
    # presence. grepl coerces NA inputs to FALSE, so restore NA explicitly to
    # preserve ignore_NA semantics (otherwise NAs would count in the denominator).
    match_binary <- as.numeric(grepl(pattern, x, perl = TRUE))
    match_binary[is.na(x)] <- NA
    
    # Ensure match_binary is numeric/logical before taking mean
    if (!is.numeric(match_binary) & !is.logical(match_binary)) {
      stop("Error: match_binary is not numeric or logical. Check input x and pattern.")
    }
    
    # Compute fraction
    if (ignore_NA) {
      return(mean(match_binary, na.rm = TRUE))
    } else {
      match_binary[is.na(match_binary)] <- replace_value
      return(mean(match_binary))
    }
  }
  
  #' Get Mapping of Original Rows to Unique Rows
  #'
  #' This function identifies unique rows in a dataframe based on specified columns 
  #' and returns a mapping of each original row to the first occurrence of its unique value.
  #'
  #' @param df A data frame containing the data to be processed.
  #' @param unique_cols A character vector of column names to determine uniqueness. 
  #'   Defaults to all columns in `df`.
  #'
  #' @return A data frame with two columns: - `x`: The row index in the original data frame. - `y`: The corresponding row index of the first unique occurrence.
  #' @examples
  #' # Example dataframe
  #' df <- data.frame(
  #'   Phylum = c(NA, NA, NA, NA, NA, NA),
  #'   Class = c(NA, NA, NA, NA, NA, NA),
  #'   Order = c(NA, NA, NA, NA, NA, NA),
  #'   Family = c(NA, NA, "Lachnospiraceae", "Porphyromonadaceae", NA, NA),
  #'   Genus = c("Clostridium", "Corynebacterium", NA, NA, "Treponema", "Treponema"),
  #'   Species = c(NA, NA, NA, NA, NA, NA)
  #' )
  #' 
  #' # Get mapping of original rows to first unique occurrence
  #' get_unique_mapping(df, c("Phylum", "Class", "Order", "Family", "Genus", "Species"))
  #'
  #' @export
  get_unique_mapping <- function(df, unique_cols = colnames(df)) {
    # Add an index column before deduplication
    df$`x` <- seq_len(nrow(df))
    
    # Find unique rows based on specified columns and assign a unique index
    df_unique <- df |>
      dplyr::distinct(across(all_of(unique_cols)), .keep_all = TRUE) |>
      dplyr::mutate(`y` = seq_len(dplyr::n()))
    
    # Create a mapping of each original row to its unique row
    df_map <- df |>
      dplyr::left_join(df_unique |> dplyr::select(-`x`), by = unique_cols) |>
      dplyr::select(`x`, `y`)
    
    return(df_map)
  }
  
  #' Get Unique Query Taxa
  #'
  #' This function deduplicates query taxa based on specified taxonomic columns.
  #'
  #' @param query A data frame containing query data.
  #' @param unique_cols A character vector specifying the taxonomic columns 
  #'   to identify unique queries.
  #'
  #' @return A data frame with distinct queries.
  #' @export
  get_query_taxa_unique <- function(query, unique_cols) {
    query |> dplyr::distinct(across(all_of(unique_cols)), .keep_all = TRUE)
  }
  
  #' Get Mapping of Original Queries to Unique Queries
  #'
  #' This function creates a mapping to restore duplicate results later.
  #' The mapping links each original row to its corresponding unique query row.
  #'
  #' @param query A data frame containing query data.
  #' @param unique_cols A character vector specifying the taxonomic columns 
  #'   to identify unique queries.
  #'
  #' @return A mapping data frame to restore duplicate results.
  #' @export
  get_query_taxa_map <- function(query, unique_cols) {
    get_unique_mapping(df = query, unique_cols = unique_cols)
  }
  
  #' Get Query Taxon Patterns
  #'
  #' This function converts unique query taxa into regular expression patterns
  #' for exact matching.  Each row of the input dataframe is wrapped with
  #' \code{\link{format_query_element}} to add \code{^...$} anchors.
  #'
  #' @param query_taxa_unique A data frame of distinct rows from \code{query_taxa}, deduplicated across taxonomic rank columns. Same structure as \code{query_taxa} but with duplicate queries removed.
  #' @return A list of one-row dataframes, each containing regex patterns for
  #'   the corresponding query.
  #' @export
  get_query_taxa_regex <- function(query_taxa_unique) {
    lapply(seq_len(nrow(query_taxa_unique)), function(i) {
      as.data.frame(apply(query_taxa_unique[i, ], c(1, 2), format_query_element))
    })
  }
  
  #' Get Unique Trait Values
  #'
  #' This function extracts unique trait values from the reference table for
  #' each trait category.
  #'
  #' @param traits_to_predict A character vector of trait categories to predict.
  #' @param table A cleaned reference table.
  #'
  #' @return A named list of unique values for each trait category.
  #' @export
  get_traits_unique <- function(traits_to_predict, table) {
    setNames(lapply(traits_to_predict, function(cat) extract_unique_values(table[[cat]])), 
             traits_to_predict)
  }
  
  #' Get Trait Regex Patterns
  #'
  #' This function converts unique trait values into regular expression patterns
  #' for delimiter-aware matching via \code{\link{format_trait_element}}.
  #'
  #' @param traits_unique A named list of unique trait values per category, derived
  #'   from \code{traits_to_predict}. Same keys as \code{traits_to_predict} but with
  #'   duplicate values removed, as returned by \code{\link{get_traits_unique}}.
  #'
  #' @return A named list of regex patterns for each trait category.
  #' @export
  get_traits_regex <- function(traits_unique) {
    setNames(lapply(names(traits_unique), function(trait) {
      sapply(traits_unique[[trait]], format_trait_element, USE.NAMES = FALSE)
    }), names(traits_unique))
  }
  
  #' Compute Matching Organisms for Each Query
  #'
  #' This function finds matching organisms in the reference table for each query.
  #'
  #' @param table A cleaned reference table.
  #' @param query_taxa_regex_list A list of one-row dataframes, each corresponding
  #'   to a row of \code{query_taxa_unique}, where values have been formatted as
  #'   regex patterns with \code{^...$} anchors via \code{format_query_element}.
  #' @param ignore_species Logical; whether to ignore the rank of species in taxa.
  #' @param match_all_ranks Logical; if TRUE, all ranks must match. Default is FALSE.
  #' @param print_matches Logical; if TRUE, prints matching organisms (Phylum through
  #'   Species) to the R console for each query. Default is TRUE.
  #'
  #' @return A list of dataframes, where each element corresponds to matching organisms 
  #'   for a unique query.
  #'
  #' @export
  compute_matching_organisms <- function(table, query_taxa_regex_list, 
                                         ignore_species = TRUE, match_all_ranks = FALSE,
                                         print_matches = FALSE) { 
    matching_organisms <- vector("list", length = length(query_taxa_regex_list))
    for (i in seq_along(query_taxa_regex_list)) {
      matching_organisms[[i]] <- filter_table_by_taxon(
        table           = table,
        query_taxa_regex = query_taxa_regex_list[[i]],
        ignore_species  = ignore_species,
        match_all_ranks = match_all_ranks,
        print_matches   = print_matches,
        query_number    = i
      )
    }
    
    return(matching_organisms)
  }
  
  #' Compute Matching Traits for Each Query
  #'
  #' This function gets matching traits for for each unique query.  It takes the
  #' output of \code{\link{compute_matching_organisms}} and removes the taxonomy
  #'  columns, leaving only trait columns.  Each element of the input list is a 
  #' dataframe that contains both taxonomy (Phylum through Species) and trait 
  #' columns; this function strips the taxonomy so the result can be passed 
  #' directly to \code{\link{compute_probabilities}}.
  #'
  #' @param matching_organisms A list of dataframes, where each element corresponds to matching organisms 
  #'   for a unique query.
  #' @param taxonomy_cols A character vector of taxonomy column names to remove.
  #'
  #' @return A list of dataframes with taxonomy columns removed, retaining only
  #'   trait columns.
  #' @export
  compute_matching_traits <- function(matching_organisms, taxonomy_cols) {
    lapply(matching_organisms, function(df) {
      dplyr::select(df, -dplyr::all_of(taxonomy_cols))
    })
  }
  
  #' Compute Probabilities of Traits for Unique Queries
  #'
  #' This function computes the probability of traits for each unique query.
  #' Progress is reported (when \code{progress_file} is non-NULL) by writing a
  #' small RDS record per iteration; the Shiny module polls this file to update
  #' the modal.  When \code{progress_file} is \code{NULL} the function runs
  #' silently, which is the intended behavior outside of Shiny.
  #'
  #' @param query_taxa_unique A data frame of distinct rows from \code{query_taxa}, deduplicated across taxonomic rank columns. Same structure as \code{query_taxa} but with duplicate queries removed.
  #' @param traits_to_predict A character vector of trait categories to predict.
  #' @param traits_unique A named list of unique trait values per category, derived
  #'   from \code{traits_to_predict}. Same keys as \code{traits_to_predict} but with
  #'   duplicate values removed, as returned by \code{\link{get_traits_unique}}.
  #' @param traits_regex A named list of regex patterns for each trait category,
  #'   derived from \code{traits_unique}, as returned by \code{\link{get_traits_regex}}.
  #' @param matching_traits A list of dataframes with matching traits.
  #' @param ignore_NA Logical; whether to ignore `NA` values. Default is `TRUE`.
  #' @param progress_file Path to a progress \code{.rds} file (typically created
  #'   by \code{create_job_filepaths()}), or \code{NULL} to disable progress
  #'   reporting.  Default is \code{NULL}.
  #' @return A data frame containing computed probabilities for each trait-category-query combination.
  #' @export
  compute_probabilities <- function(query_taxa_unique, traits_to_predict, traits_unique, 
                                    traits_regex, matching_traits, ignore_NA = TRUE,
                                    progress_file = NULL) {
    # Initialize values
    results_list <- vector("list", sum(sapply(traits_unique, length)) * nrow(query_taxa_unique) * length(traits_to_predict))
    idx <- 1
    
    # Loop through each unique query and compute probabilities
    for (i in seq_len(nrow(query_taxa_unique))) {
      match <- matching_traits[[i]]
      query_taxa_row <- query_taxa_unique[i, ]
      
      for (trait_col in traits_to_predict) {
        pattern <- traits_regex[[trait_col]]
        trait_values <- match |> 
          dplyr::pull(trait_col)
        
        for (k in seq_along(traits_unique[[trait_col]])) {
          results_list[[idx]] <- list(
            `y` = i,
            `Phylum` = query_taxa_row["Phylum"],
            `Class` = query_taxa_row["Class"],
            `Order` = query_taxa_row["Order"],
            `Family` = query_taxa_row["Family"],
            `Genus` = query_taxa_row["Genus"],
            `Species` = query_taxa_row["Species"],
            `Trait category` = trait_col,
            `Trait name` = traits_unique[[trait_col]][k],
            `Probability` = match_fraction(trait_values, pattern[k], ignore_NA = ignore_NA)
          )
          idx <- idx + 1
        }
      }
      
      # Update progress
      write_progress(progress_file,
                     progress = i / nrow(query_taxa_unique),
                     message  = "Prediction in progress")
    }
    
    # Bind results and flatten any nested dataframes
    results_df <- dplyr::bind_rows(results_list) |>
      dplyr::mutate(dplyr::across(where(is.data.frame), ~ .[[1]]))
    
    return(results_df)
    
  }
  
  #' Restore Duplicate Rows from Unique Queries
  #'
  #' This function restores duplicate rows that were removed when identifying unique queries.
  #' It maps computed results back to the original queries.
  #'
  #' @param df_unique A data frame containing computed results for unique queries.
  #' @param query_map A mapping data frame that links original rows to unique query rows.
  #' @return A data frame with duplicate rows restored.
  #' @export
  restore_duplicates <- function(df_unique, query_map) {
    query_map |>
      dplyr::left_join(df_unique, by = "y", relationship = "many-to-many") |>
      dplyr::select(-`y`) |>
      dplyr::rename(`Organism number` = `x`)
  }
  
  #' Predict Trait Probabilities from Query and Reference Table
  #'
  #' This function computes probabilities of traits for a given query taxa table
  #' using a reference table and pre-specified trait categories.
  #'
  #' @param query A formatted query data frame.
  #' @param table A cleaned reference table.
  #' @param traits_to_predict A character vector of trait categories to predict.
  #' @param ignore_NA Logical; whether to ignore `NA` values. Default is `TRUE`.
  #' @param ignore_species Logical; whether to ignore the rank of species in taxa.
  #' @param match_all_ranks Logical; if TRUE, all ranks must match. Default is FALSE.
  #' @param print_matches Logical; if TRUE, prints matching organisms (Phylum through
  #'   Species) to the R console. Default is TRUE.
  #' @param progress_file Path to a progress \code{.rds} file (typically created
  #'   by \code{create_job_filepaths()}), or \code{NULL} to disable progress
  #'   reporting.  Default is \code{NULL}.
  #' @return A data frame of predicted trait probabilities.
  #' @export
  predict_traits_taxonomy <- function(query, table, traits_to_predict, ignore_NA = TRUE,
                                      ignore_species = TRUE, match_all_ranks = FALSE,
                                      print_matches = FALSE,
                                      progress_file = NULL) {
    unique_cols <- c("Phylum", "Class", "Order", "Family", "Genus", "Species")
    
    query_taxa_unique <- get_query_taxa_unique(query, unique_cols)
    query_map <- get_query_taxa_map(query, unique_cols)
    query_taxa_regex_list <- get_query_taxa_regex(query_taxa_unique)
    
    traits_unique <- get_traits_unique(traits_to_predict, table)
    traits_regex <- get_traits_regex(traits_unique)
    
    matching_organisms <- compute_matching_organisms(
      table                = table,
      query_taxa_regex_list = query_taxa_regex_list,
      ignore_species       = ignore_species,
      match_all_ranks      = match_all_ranks,
      print_matches        = print_matches
    )
    
    matching_traits <- compute_matching_traits(
      matching_organisms = matching_organisms,
      taxonomy_cols      = colnames(query_taxa_unique)
    )
    
    results_unique <- compute_probabilities(
      query_taxa_unique  = query_taxa_unique,
      traits_to_predict  = traits_to_predict,
      traits_unique      = traits_unique,
      traits_regex       = traits_regex,
      matching_traits    = matching_traits,
      ignore_NA          = ignore_NA,
      progress_file      = progress_file
    )
    
    restore_duplicates(results_unique, query_map)
  }
  
  #' Compute Predictions from Taxonomy
  #'
  #' This is the main function for predicting traits in the module.  
  #'
  #' @param data A data frame loaded with organism metadata (the app database).
  #' @param query_taxa A data frame of taxonomic rank columns (Phylum, Class, Order, Family, Genus, Species) with plain text values representing the taxa to query. May contain \code{NA} for unspecified ranks.
  #' @param query_string A character string representing the query used to filter the organisms.
  #' @param traits_to_predict A character vector of trait categories to predict.
  #' @param ignore_NA Logical; whether to ignore `NA` values. Default is `TRUE`.
  #' @param match_all_ranks Logical; if TRUE, all ranks must match. Default is FALSE.
  #' @param ignore_species Logical; whether to ignore the rank of species in taxa.
  #' @param system_taxonomy A character string giving the taxonomy system (e.g. `"LPSN"`). Default is `"LPSN"`. If `NULL` or invalid, falls back to `"LPSN"`.
  #' @param print_matches Logical; if TRUE, prints matching organisms (Phylum through
  #'   Species) to the R console. Default is TRUE.
  #' @param progress_file Path to a progress \code{.rds} file (typically created
  #'   by \code{create_job_filepaths()}), or \code{NULL} to disable progress
  #'   reporting.  Default is \code{NULL}.
  #' @return A named list with trait probabilities.
  #' @export
  compute_taxonomy_predictions <- function(data, query_taxa, query_string, traits_to_predict,
                                           ignore_NA, match_all_ranks, ignore_species,
                                           system_taxonomy, print_matches = TRUE,
                                           progress_file = NULL) {
    # Update progress
    write_progress(progress_file, 0, "Getting data")
    
    # Get reference table (full taxonomy universe; NA semantics handled downstream)
    table <- get_reference_table(data, system_taxonomy, traits_to_predict, query_string)
    
    # Get query taxa
    query_taxa <- format_query_taxa(query_taxa)
    
    # Update progress
    write_progress(progress_file, 0, "Prediction in progress")
    
    # Get trait probabilities
    probabilities <- predict_traits_taxonomy(
      query_taxa, table, traits_to_predict,
      ignore_NA       = ignore_NA,
      ignore_species  = ignore_species,
      match_all_ranks = match_all_ranks,
      progress_file   = progress_file
    )
    
    # Update progress
    cat(file = stderr(), paste0("Ended prediction at ", Sys.time(), "\n"))
    
    return(list(probabilities = probabilities))
  }

  #' Run a computation job for the taxonomy module
  #'
  #' This functions runs a computation job for module.  It involves running the 
  #' main function for predicting traits then saving the result to a file.
  #'
  #' @param query_taxa A data frame of taxonomic rank columns.
  #' @param query_string A character string giving the database filter.
  #' @param traits_to_predict A character vector of trait categories.  
  #' @param ignore_NA Logical.
  #' @param match_all_ranks Logical.
  #' @param ignore_species Logical.
  #' @param system_taxonomy A character string giving the taxonomy system.
  #' @param metadata A data frame of organism metadata to show in the tree hover text, or NULL.
  #' @param job_id Character job id.
  #' @param job_dir Directory where the result file is to be written.
  #' @param progress_file Path to the progress \code{.rds} file, or \code{NULL}.
  #' @return Invisibly \code{TRUE}.
  #' @export
  run_job_taxonomy <- function(query_taxa, 
                               query_string, 
                               traits_to_predict,
                               ignore_NA, 
                               match_all_ranks, 
                               ignore_species,
                               system_taxonomy, 
                               metadata = NULL,
                               job_id, 
                               job_dir,
                               progress_file = NULL
   ) {
    data <- load_database()
    
    result <- compute_taxonomy_predictions(
      data              = data,
      query_taxa        = query_taxa,
      query_string      = query_string,
      traits_to_predict = traits_to_predict,
      ignore_NA         = ignore_NA,
      match_all_ranks   = match_all_ranks,
      ignore_species    = ignore_species,
      system_taxonomy   = system_taxonomy,
      progress_file     = progress_file
    )

    payload <- list(
      query_taxa        = query_taxa,
      query_string      = query_string,
      traits_to_predict = traits_to_predict,
      ignore_NA         = ignore_NA,
      match_all_ranks   = match_all_ranks,
      ignore_species    = ignore_species,
      system_taxonomy   = system_taxonomy,
      organism_metadata = metadata,
      predict_traits    = result$probabilities
    )

    save_job_result(job_id = job_id, result = payload, job_dir = job_dir)

    invisible(TRUE)
  }

# === Processing taxonomy ===
  #' Check if String has Taxonomy in QIIME2 or MetaPhlAn Format
  #' 
  #' This helper function is used to detect if a string follows QIIME2 or
  #' MetaPhlAn format.  It checks for presence of taxonomic prefixes 
  #' (like k__, p__), which both formats use.  It also checks for presence 
  #' of semicolon seperators (used by QIIME2) and pipe separators 
  #' (used by MetaPhlAn).
  #'
  #' @param x A single character string.
  #' @return One of "QIIME2", "MetaPhlAn", or "Unknown".
  #' @examples
  #' classify_taxonomy_string("k__Bacteria; p__Firmicutes; c__Bacilli")
  #' classify_taxonomy_string("k__Bacteria|p__Firmicutes|c__Bacilli")
  #' classify_taxonomy_string("UNCLASSIFIED")
  classify_taxonomy_string <- function(x) {
    x <- as.character(x)
    
    has_prefix <- grepl("k__|p__|c__|o__|f__|g__|s__", x, perl = TRUE)
    has_semicolon <- grepl(";", x, fixed = TRUE)
    has_pipe <- grepl("|", x, fixed = TRUE)
    
    if (has_prefix && has_semicolon && !has_pipe) {
      return("qiime2")
    } else if (has_prefix && has_pipe && !has_semicolon) {
      return("metaphlan")
    } else {
      return("unknown")
    }
  }
  
  #' Split Taxonomy String into Taxonomic Ranks
  #'
  #' This function splits a string containing an organism's full taxonomy into
  #' individual ranks. It can accommodate both QIIME2 and MetaPhlAn-style
  #' strings. By default, it extracts the species epithet
  #' (e.g., "coli" in "Escherichia coli" or "epidermidis" from "Staphylococcus_epidermidis").
  #'
  #' @param taxonomy A character string with the organism's taxonomy, e.g.,
  #'   "d__Bacteria;p__Pseudomonadota;c__Gammaproteobacteria;o__Burkholderiales;f__Burkholderiaceae;g__Bordetella;s__Bordetella pseudohinzii".
  #' @param rank_sep The delimiter between ranks (e.g., ";" for QIIME2, "|" for MetaPhlAn).
  #' @param ranks Vector of rank names.
  #' @param prefixes Vector of corresponding prefixes.
  #' @param extract_species_epithet Logical. If `TRUE` (default), the species
  #'   column contains only the epithet (e.g., "coli" from "Escherichia coli").
  #'   If `FALSE`, the full species name is returned.
  #' @param sp_sep The delimiter between genus and species (e.g., " " for QIIME2, "_" for MetaPhlAn).
  #' 
  #' @return A named character vector with taxonomic ranks.
  #'
  #' @examples
  #' split_taxonomy_string("k__Bacteria; p__Firmicutes; c__Bacilli; o__Lactobacillales; f__Streptococcaceae; g__Streptococcus; s__Streptococcus pneumoniae", rank_sep = ";", sp_sep = " ")
  #' split_taxonomy_string("k__Bacteria|p__Firmicutes|c__Bacilli|o__Lactobacillales|f__Streptococcaceae|g__Streptococcus|s__Streptococcus_pneumoniae", rank_sep = "|", sp_sep = "_")
  split_taxonomy_string <- function(
    taxonomy,
    rank_sep = ";",
    ranks = c("Phylum", "Class", "Order", "Family", "Genus", "Species"),
    prefixes = paste0(substr(tolower(ranks), 1, 1), "__"),
    extract_species_epithet = TRUE,
    sp_sep = " "
  ) {
    parts <- strsplit(taxonomy, rank_sep, fixed = TRUE)[[1]]
    out <- setNames(rep(NA_character_, length(ranks)), ranks)
    
    for (item in parts) {
      item <- trimws(item)  # remove leading/trailing spaces
      for (i in seq_along(prefixes)) {
        prefix <- prefixes[i]
        if (startsWith(item, prefix)) {
          val <- sub(paste0("^", prefix), "", item)
          if (ranks[i] == "Species" && extract_species_epithet) {
            val <- sub(paste0(".*", sp_sep), "", val)
          }
          out[ranks[i]] <- val
          break
        }
      }
    }
    
    return(out)
  }
  
  #' Check if Data Follows DADA2 Format
  #'
  #' This function checks if the data contains columns expected in the DADA2 format.
  #'
  #' @param data A data frame. The data to check.
  #' @return Logical. TRUE if the data follows DADA2 format, FALSE otherwise.
  #' @export
  is_dada2_format <- function(data) {
    all(c("Phylum", "Class", "Order", "Family", "Genus") %in% colnames(data))
  }
  
  #' Check if Data Follows QIIME2 Format
  #'
  #' This function checks if the data contains taxonomy in QIIME2-format.
  #' It does this by scanning all columns for the QIIME2 taxonomy pattern.
  #'
  #' @param data A data frame. The data to check.
  #' @return Logical. TRUE if the data follows QIIME2 format, FALSE otherwise.
  #' @export
  is_qiime2_format <- function(data) {
    if (!is.data.frame(data)) return(FALSE)
    
    any(
      sapply(data, function(col) {
        any(sapply(col, classify_taxonomy_string) == "qiime2", na.rm = TRUE)
      })
    )
  }
  
  #' Check if Data Follows MetaPhlAn Format
  #'
  #' This function checks if the data contains taxonomy in MetaPhlAn-format.
  #' It does this by scanning all columns for the MetaPhlAn taxonomy pattern.
  #'
  #' @param data A data frame. The data to check.
  #' @return Logical. TRUE if any column contains MetaPhlAn-formatted taxonomy, FALSE otherwise.
  #' @export
  is_metaphlan_format <- function(data) {
    if (!is.data.frame(data)) return(FALSE)
    
    any(
      sapply(data, function(col) {
        any(sapply(col, classify_taxonomy_string) == "metaphlan", na.rm = TRUE)
      })
    )
  }
  
  #' Check if Data Follows IMG Genome Format
  #'
  #' This function checks if the data contains taxonomic columns expected in the IMG genome format.
  #' It detects either the NCBI taxonomy columns or the GTDB taxonomy columns.
  #'
  #' @param data A data frame.
  #' @return Logical. TRUE if the data follows the IMG genome format, FALSE otherwise.
  #' @export
  is_img_format <- function(data) {
    ncbi_cols <- c("NCBI Phylum", "NCBI Class", "NCBI Order", "NCBI Family", "NCBI Genus", "NCBI Species")
    gtdb_cols <- c("GTDB Phylum", "GTDB Class", "GTDB Order", "GTDB Family", "GTDB Genus", "GTDB Species")
    
    has_ncbi <- all(ncbi_cols %in% colnames(data))
    has_gtdb <- all(gtdb_cols %in% colnames(data))
    
    return(has_ncbi || has_gtdb)
  }
  
  #' Process DADA2 Format
  #'
  #' Selects the expected taxonomy columns from a DADA2-style dataframe.
  #'
  #' @param data A data frame in DADA2 format.
  #' @return A data frame with `Phylum` to `Species` columns.
  #' @export
  process_dada2_format <- function(data) {
    if (!"Species" %in% colnames(data)) {
      data$Species <- NA_character_
    }

    data <- data |> dplyr::select(Phylum, Class, Order, Family, Genus, Species)
    return(data)
  }
  
  #' Process QIIME2 Format
  #'
  #' Splits QIIME2-style taxonomy strings into separate columns.
  #'
  #' @param data A data frame containing a column with QIIME2-formatted taxonomy.
  #' @return A data frame with columns `Phylum`, `Class`, `Order`, `Family`, `Genus`, `Species`.
  #' @export
  process_qiime2_format <- function(data) {
    # Find the column that contains QIIME2-format taxonomy
    taxonomy_col <- names(data)[
      which.max(
        sapply(data, function(col) any(sapply(col, classify_taxonomy_string) == "qiime2", na.rm = TRUE))
      )
    ]
    
    if (is.na(taxonomy_col) || taxonomy_col == "") {
      stop("No QIIME2-formatted column found.")
    }
    
    # Split the strings into separate columns
    taxonomy_vec <- as.character(data[[taxonomy_col]])
    
    out_list <- vector("list", length(taxonomy_vec))
    for (i in seq_along(taxonomy_vec)) {
      out_list[[i]] <- split_taxonomy_string(
        taxonomy = taxonomy_vec[i],
        rank_sep = ";",
        sp_sep = " ",
        extract_species_epithet = TRUE
      )
    }
    
    # Combine results
    df <- do.call(rbind, out_list)
    rownames(df) <- NULL
    df <- (as.data.frame(df))
    
    return(df)
  }
  
  
  #' Process MetaPhlAn Format
  #'
  #' Splits MetaPhlAn-style taxonomy strings into separate columns.
  #' Only rows beginning with `k__` are included; others like `UNCLASSIFIED` are excluded.
  #'
  #' @param data A data frame containing a column with MetaPhlAn-formatted taxonomy.
  #' @return A data frame with columns `Phylum`, `Class`, `Order`, `Family`, `Genus`, `Species`.
  #' @export
  process_metaphlan_format <- function(data) {
    # Find the column that contains MetaPhlAn-format taxonomy
    taxonomy_col <- names(data)[
      which.max(
        sapply(data, function(col) any(sapply(col, classify_taxonomy_string) == "metaphlan", na.rm = TRUE))
      )
    ]
    
    if (is.na(taxonomy_col) || taxonomy_col == "") {
      stop("No MetaPhlAn-formatted column found.")
    }
    
    # Split the strings into separate columns
    taxonomy_vec <- as.character(data[[taxonomy_col]])
    taxonomy_vec <- gsub("\\t.*$", "", taxonomy_vec)         # Strip extra fields
    taxonomy_vec <- taxonomy_vec[grepl("^k__", taxonomy_vec)] # Keep valid rows
    
    out_list <- vector("list", length(taxonomy_vec))
    for (i in seq_along(taxonomy_vec)) {
      out_list[[i]] <- split_taxonomy_string(
        taxonomy = taxonomy_vec[i],
        rank_sep = "|",
        sp_sep = "_",
        extract_species_epithet = TRUE
      )
    }
    
    # Combine results
    df <- do.call(rbind, out_list)
    rownames(df) <- NULL
    df <- (as.data.frame(df))
    
    return(df)
  }
  
  #' Process IMG Genome Format
  #'
  #' Selects and renames GTDB or NCBI taxonomy columns from IMG genome tables.
  #' By default, it prioritizes NCBI taxonomy columns unless `prefer = "GTDB"` is specified.
  #' It can also optionally extract just the species epithet (e.g., "coli" from "Escherichia coli").
  #'
  #' @param data A data frame containing GTDB or NCBI taxonomy columns.
  #' @param prefer Character. Which taxonomy to prioritize if both are present: "NCBI" (default) or "GTDB".
  #' @param extract_species_epithet Logical. If `TRUE` (default), returns only the species epithet
  #'   in the `Species` column; if `FALSE`, returns full species name.
  #'
  #' @return A data frame with columns `Phylum` to `Species`, or NULL if neither taxonomy is available.
  #' @export
  process_img_genome_format <- function(data, prefer = c("NCBI", "GTDB"), extract_species_epithet = TRUE) {
    prefer <- match.arg(prefer)
    
    gtdb_cols <- c("GTDB Phylum", "GTDB Class", "GTDB Order", "GTDB Family", "GTDB Genus", "GTDB Species")
    ncbi_cols <- c("NCBI Phylum", "NCBI Class", "NCBI Order", "NCBI Family", "NCBI Genus", "NCBI Species")
    
    has_gtdb <- all(gtdb_cols %in% colnames(data))
    has_ncbi <- all(ncbi_cols %in% colnames(data))
    
    select_and_rename <- function(cols, prefix) {
      df <- data |>
        dplyr::select(dplyr::all_of(cols)) |>
        dplyr::rename_with(~ gsub(paste0("^", prefix, " "), "", .x))
      
      if (extract_species_epithet && "Species" %in% colnames(df)) {
        df <- df |>
          dplyr::mutate(Species = sub(".*\\s", "", Species))
      }
      
      return(df)
    }
    
    if (prefer == "NCBI" && has_ncbi) {
      return(select_and_rename(ncbi_cols, "NCBI"))
    } else if (prefer == "GTDB" && has_gtdb) {
      return(select_and_rename(gtdb_cols, "GTDB"))
    } else if (has_ncbi) {
      return(select_and_rename(ncbi_cols, "NCBI"))
    } else if (has_gtdb) {
      return(select_and_rename(gtdb_cols, "GTDB"))
    } else {
      return(NULL)
    }
  }
  
#' Process Uploaded Taxonomy File
  #'
  #' This function processes an uploaded taxonomy file, detecting whether it follows
  #' the DADA2, QIIME2, or IMG genome format, and reformats the data accordingly.
  #'
  #' @param query A data frame. The uploaded taxonomy data.
  #' @return A processed data frame with standard taxonomic ranks or NULL if format is unrecognized.
  #' @export
  process_uploaded_taxonomy  <- function(query) {
    if (!is.data.frame(query)) return(NULL)
    if (is_dada2_format(query)) {
      return(process_dada2_format(query))
    } else if (is_qiime2_format(query)) {
      return(process_qiime2_format(query))
    } else if (is_metaphlan_format(query)) {
      return(process_metaphlan_format(query))
    } else if (is_img_format(query)) {
      return(process_img_genome_format(query))
    } else {
      return(NULL)
    }
  }
  
  #' Get Query Taxa from Uploaded File
  #'
  #' This helper function reads and processes a taxonomy file uploaded by the user.
  #' It first validates and reads the file based on its extension, and then processes it according
  #' to the detected format (DAADA, QIIME2, MetaPhlAn, IMG)
  #'
  #' @param upload_path A character string. Path to the uploaded file.
  #' @param session The Shiny session object. Defaults to the current reactive domain.
  #' @return A processed data frame with standard taxonomic ranks or NULL if format is unrecognized.
  #' @export
  get_query_taxa_from_upload <- function(upload_path, session = shiny::getDefaultReactiveDomain()) {
    query <- validate_and_read_file(file_path = upload_path)
    query <- process_uploaded_taxonomy(query)
    
    return(query)
  }
  
# === Other ===
  #' Add Custom Traits Based on Query
  #'
  #' This function processes a data table by applying a query to identify organisms with 
  #' positive traits, then adds a column (default: 'Custom trait') to indicate which 
  #' organisms have these traits.
  #'
  #' @param data A data frame containing the organism data.
  #' @param query_string A character string representing the query used to filter the organisms.
  #' @param ignore_NA Logical; if `TRUE`, organisms with `NA` values are excluded from the final result. Default is `FALSE`.
  #' @param trait_name A string specifying the name of the new trait column. Default is "Custom trait".
  #' @return A data frame with the trait column added, indicating positive traits.
  #' @export
  #' @importFrom dplyr mutate if_else left_join filter select
  #' @importFrom tidyr replace_na
  add_custom_traits <- function(data, query_string, ignore_NA = FALSE, trait_name = "Custom trait") {
    # Validate that the query string is not empty
    if(query_string == "") {
      stop("Please build a valid query.")
    }
    
    # Add an index column to the data
    data$index <- seq_len(nrow(data))
    
    # Get data for organisms with positive traits
    data_positive <- filter_data_by_query(data, query_string)

    # Add a new column 'Custom trait' to data_positive
    data_positive <- data_positive |>
      dplyr::mutate(`Custom trait` = dplyr::if_else(dplyr::n() > 0, "positive", NA_character_))
    
    # Get data for all organisms (excluding those with NA values if specified)
    data_all <- if (ignore_NA) {
      filter_data_excluding_na(data, query_string)
    } else {
      data
    }

    # Merge the positive trait data back using the index column
    data <- dplyr::left_join(
      data_all,
      data_positive[, c("index", trait_name)],
      by = "index"
    )
    
    # Fill NA values in 'Custom trait' column with "-"
    data[[trait_name]] <- tidyr::replace_na(data[[trait_name]], "negative")

    return(data)
  }
  
  #' Get Query Taxa from the Database
  #' 
  #' This function takes query organisms and retrieves their taxonomy from the 
  #' database.  Query organisms are formatted as "Taxon_Name (Rank)".  For 
  #' query organisms that are species, the format is "Genus_Name species_epithet
  #' (Species)".  Thefunction takes a dataframe with columns for taxonomic ranks 
  #' and puts the query organisms in it.  It fills in names for other ranks using 
  #' values from the database.  Only names for higher ranks (e.g., Phylum) are 
  #' filled in, and lower ranks (e.g., Species) are set to `NA`.
  #'
  #' @param selected_organisms A character vector of taxon strings, where each entry follows the format `"Taxon_Name (Rank)"`.
  #' @param system_taxonomy A character string giving the taxonomy system (e.g. `"LPSN"`). Default is `"LPSN"`. If `NULL` or invalid, falls back to `"LPSN"`.
  #' @return A data frame with columns "Phylum", "Class", "Order", "Family", "Genus", "Species", with the provided taxon names placed in the appropriate rank columns and other values filled in.
  #' @examples
  #' selected_taxa <- c("Abditibacteriota (Phylum)", "Bacilli (Class)", "Lactobacillales (Order)")
  #' get_query_taxa_from_database(selected_taxa)
  #'
  #' @export
  get_query_taxa_from_database <- function(selected_organisms, system_taxonomy = "LPSN") {
    # Load database
    database <- load_database()
    col_name <- paste0(system_taxonomy, " Taxonomy")
    database <- expand_and_merge_taxonomy(data = database, col_name = col_name, drop_species = FALSE)
    
    
    # Initialize the dataframe to hold the query
    ranks <- c("Phylum", "Class", "Order", "Family", "Genus", "Species")
    query <- as.data.frame(matrix(NA, nrow = length(selected_organisms), ncol = length(ranks)))
    colnames(query) <- ranks
    
    # Loop through each value in selected_organisms
    for (i in seq_along(selected_organisms)) {
      extracted <- gsub(" \\(.*\\)", "", selected_organisms[i])  # Remove the parenthetical part
      rank <- gsub(".*\\((.*)\\)", "\\1", selected_organisms[i]) # Extract the rank
      
      # Assign the extracted value to the correct column, if the rank exists
      if (rank %in% ranks) {
        query[i, rank] <- extracted
      } else {
        warning(sprintf("Invalid rank: '%s' in '%s'. Expected one of %s", 
                        rank, selected_organisms[i], paste(ranks, collapse = ", ")))
      }
      
      # For species, split the full binomial (e.g., "Escherichia coli") into
      # genus and epithet, since the database stores only the epithet in Species
      if (rank == "Species") {
        parts      <- strsplit(extracted, " ")[[1]]
        genus_name <- parts[1]                         # e.g., "Escherichia"
        epithet    <- paste(parts[-1], collapse = " ") # e.g., "coli"
        
        query[i, "Genus"]   <- genus_name
        query[i, "Species"] <- epithet
        
        lookup_col   <- "Species"
        lookup_value <- epithet
      } else {
        lookup_col   <- rank
        lookup_value <- extracted
      }
      
      # Fill in higher ranks 
      if (rank == "Species") {
        matches <- database[!is.na(database[[lookup_col]]) & 
                              database[[lookup_col]] == lookup_value &
                              !is.na(database[["Genus"]]) &
                              database[["Genus"]] == genus_name, , drop = FALSE]
      } else {
        matches <- database[!is.na(database[[lookup_col]]) & database[[lookup_col]] == lookup_value, , drop = FALSE]
      }
      if (nrow(matches) > 0) {
        key_cols <- intersect(colnames(matches), ranks)
        
        # Most common row among matches (ties broken arbitrarily)
        top_row <- matches |>
          dplyr::count(dplyr::across(dplyr::all_of(key_cols)), name = "..n") |>
          dplyr::arrange(dplyr::desc(.data[["..n"]])) |>
          dplyr::slice(1) |>
          dplyr::select(-"..n")
        
        higher_cols <- ranks[seq_len(match(rank, ranks))]
        for (col in higher_cols) {
          val <- top_row[[col]][[1]]
          if (!is.null(val) && !is.na(val)) query[i, col] <- val
        }
      } else {
        warning(sprintf("Invalid rank: '%s' in '%s'. Expected one of %s", 
                        rank, selected_organisms[i], paste(ranks, collapse = ", ")))
      }
    }
    
    return(query)
  }
  
  #' Clean taxon data by replacing placeholders, removing suffixes, and stripping brackets
  #'
  #' This function replaces common placeholder values (e.g., "", "?", "unclassified") with `NA`,
  #' removes specified suffixes (e.g., "_unclassified"), and strips characters from specified brackets.
  #'
  #' @param df A data frame of taxonomic data.
  #' @param missing_values A character vector of values to treat as missing. Defaults to "", "?", and "unclassified".
  #' @param suffixes_to_remove A character vector of suffixes to strip from values (e.g., "_unclassified").
  #' @param brackets_to_remove A string of bracket characters to remove (e.g., "[]{}()"). Defaults to "[]".
  #'
  #' @return A cleaned data frame.
  #' @export
  #'
  #' @examples
  #' cleaned <- clean_taxon_data(taxon_df)
  clean_taxon_data <- function(
    df,
    missing_values = c("", "?", "unclassified"),
    suffixes_to_remove = c("_unclassified"),
    brackets_to_remove = "[]"
  ) {
    # Escape bracket characters for regex
    brackets_regex <- paste0("[", gsub("([][(){}.^$*+?|\\\\])", "\\\\\\1", brackets_to_remove), "]")
    
    df[] <- lapply(df, function(x) {
      if (is.character(x) || is.factor(x)) {
        x <- as.character(x)
        x[x %in% missing_values] <- NA
        x <- gsub(brackets_regex, "", x)  # Remove bracket characters
        
        for (suffix in suffixes_to_remove) {
          pattern <- paste0(suffix, "$")
          x <- gsub(pattern, "", x)
        }
      }
      return(x)
    })
    return(as.data.frame(df))
  }
  
  #' Format Query Taxa Table
  #'
  #' This function cleans and formats a query taxa dataframe by replacing missing values.
  #'
  #' @param query A data frame of taxonomic ranks for query organisms.
  #' @return A formatted version of the query data frame.
  #' @export
  format_query_taxa <- function(query) {
    query <- clean_taxon_data(query)

    return(query)
  }

  #' Get Choices for Taxa
  #'
  #' This function extracts unique taxonomic names from a data frame and appends 
  #' the corresponding rank in parentheses.
  #'
  #' @param data A data frame containing taxonomic ranks as columns (e.g., "Phylum", "Class", "Order", "Family", "Genus", "Species"), with taxon names as values.
  #' @return A character vector of unique taxon names formatted as "Taxon_Name (Rank)".
  #'
  #' @examples
  #' taxon_df <- data.frame(
  #'   Phylum = c("Abditibacteriota", "Bacillota", "Bacillota"),
  #'   Class = c("Abditibacteriia", "Bacilli", "Erysipelotrichia"),
  #'   Order = c("Abditibacteriales", "Lactobacillales", "Erysipelotrichales")
  #' )
  #' 
  #' get_taxa_choices(taxon_df)
  #'
  #' @export
  get_taxa_choices <- function(data) {
    # Get column names as taxonomic ranks
    ranks <- c("Phylum", "Class", "Order", "Family", "Genus")
    
    # Format names of phylum through genus
    higher_ranks <- c("Phylum", "Class", "Order", "Family", "Genus")
    higher_choices <- unlist(mapply(function(col, rank) {
      paste(data[[col]], sprintf("(%s)", rank))
    }, higher_ranks, higher_ranks, SIMPLIFY = FALSE))
    
    # Format names of species 
    species_choices <- data |>
      dplyr::filter(!is.na(Species) & Species != "") |>
      dplyr::mutate(label = paste(Genus, Species, "(Species)")) |>
      dplyr::pull(label)
    
    # Combine, ensure unique values, and remove names
    choices <- unique(unname(c(higher_choices, species_choices)))
    
    return(choices)
  }
  
# === Functions for display of matching organisms ===
  #' Get Matching Organisms for a Single Query Taxon
  #'
  #' This function computes the reference-table organisms that match a single
  #' query taxon row, returning them as a tidy dataframe suitable for display
  #' in the Shiny UI.  It re-uses the same matching logic as the main prediction
  #' pipeline but only runs for the one row the user has selected.  The
  #' reference table is built with \code{\link{get_reference_table}} so the
  #' columns (Phylum through Species plus \code{traits_to_predict}) are identical
  #' to those produced by \code{\link{compute_matching_organisms}}.
  #'
  #' @param query_taxa_row A single-row data frame with columns Phylum, Class, Order, Family, Genus, Species (as stored in \code{get_results()$query_taxa}).
  #' @param data The full database (a data frame loaded by `load_database()`).
  #' @param traits_to_predict A character vector of trait categories to predict.
  #' @param query_string Optional custom trait query string (or `NULL`). As saved in the job result.
  #' @param ignore_species Logical; whether to ignore species rank when matching.
  #'   Should match the value used for the current job. Default \code{TRUE}.
  #' @param match_all_ranks Logical; if TRUE, all ranks must match.
  #'   Should match the value used for the current job. Default \code{FALSE}.
  #' @param system_taxonomy A character string giving the taxonomy system (e.g. `"LPSN"`). Default is `"LPSN"`. If `NULL` or invalid, falls back to `"LPSN"`.
  #' @return A data frame with the same columns as \code{compute_matching_organisms}: Phylum, Class, Order, Family, Genus, Species, plus the trait columns from \code{traits_to_predict}. Returns an empty data frame (zero rows) if no organisms matched.
  #' @export
  get_matching_organisms_for_query <- function(query_taxa_row,
                                               data,
                                               traits_to_predict,
                                               query_string    = NULL,
                                               ignore_species  = TRUE,
                                               match_all_ranks = FALSE,
                                               system_taxonomy = "LPSN") {
    # Format the row (clean NAs, placeholders, etc.)
    query_taxa_row <- format_query_taxa(query_taxa_row)

    # Build the reference table via the same path as the main pipeline,
    # so columns are Phylum:Species + traits_to_predict only.  The table is the
    # full taxonomy universe; NA filtering is not applied here so that taxa
    # with no annotated traits still match.
    table <- get_reference_table(
      data              = data,
      system_taxonomy   = system_taxonomy,
      traits_to_predict = traits_to_predict,
      query_string      = query_string
    )

    # Convert to regex and run matching
    query_taxa_regex_list <- get_query_taxa_regex(query_taxa_row)

    filter_table_by_taxon(
      table            = table,
      query_taxa_regex = query_taxa_regex_list[[1]],
      ignore_species   = ignore_species,
      match_all_ranks  = match_all_ranks,
      print_matches    = FALSE
    )
  }
  
  #' Format Query Taxa Rows as Picker Choices
  #'
  #' Converts a \code{query_taxa} dataframe (as saved in a job result) into a
  #' named character vector suitable for a \code{pickerInput}.  Each element is
  #' labelled \code{"Query N: Rank1 / Rank2 / ..."} using only the non-NA rank
  #' values for that row, and the value is the row index \code{N} so the server
  #' can look up the correct row without any label-parsing.
  #'
  #' @param query_taxa A data frame with columns Phylum, Class, Order, Family, Genus, Species, one row per query organism.
  #' @return A named character vector where names are the display labels and
  #'   values are character row indices (\code{"1"}, \code{"2"}, ...).
  #' @export
  format_query_taxa_choices <- function(query_taxa) {
    rank_cols <- c("Phylum", "Class", "Order", "Family", "Genus", "Species")
    
    labels <- vapply(seq_len(nrow(query_taxa)), function(i) {
      row  <- as.list(query_taxa[i, ])
      vals <- vapply(rank_cols, function(r) {
        v <- row[[r]]
        if (!is.null(v) && !is.na(v) && v != "" && v != "NA") v else NA_character_
      }, character(1))
      vals <- vals[!is.na(vals)]
      paste0("Query ", i, ": ", paste(vals, collapse = " / "))
    }, character(1))
    
    # values are row indices as strings
    stats::setNames(as.character(seq_len(nrow(query_taxa))), labels)
  }
  
# === Updating user interface (UI) elements ===
  #' Update Choices for Taxonomy from Database (Taxonomy Module)
  #'
  #' Populates the \code{query_taxa} selectize input with taxa drawn
  #' from the currently selected taxonomy system (LPSN, GTDB, or NCBI).
  #' Defaults the selection to genus \emph{Escherichia} and falls back to
  #' \code{"LPSN"} when the system is not yet set.
  #'
  #' @param session The Shiny session object. Defaults to the current reactive domain.
  #' @param system_taxonomy A character string giving the taxonomy system (e.g. `"LPSN"`). Default is `"LPSN"`. If `NULL` or invalid, falls back to `"LPSN"`.
  #' @return Invisibly \code{NULL}. Called for its side effect of updating
  #'   the \code{query_taxa} selectize input.
  #' @export
  update_query_taxa_taxonomy <- function(session = shiny::getDefaultReactiveDomain(),
                                                system_taxonomy = NULL) {
    # Get data
    database <- load_database()
    
    # Get inputs
    system_taxonomy <- assign_if_invalid(system_taxonomy, "LPSN")
    
    # Get choices
    col_name <- paste0(system_taxonomy, " Taxonomy")
    choices <- expand_and_merge_taxonomy(data = database, col_name = col_name, drop_species = FALSE)
    choices <- get_taxa_choices(choices)
    
    selected <- c("Escherichia (Genus)")
    
    # Update UI
    update_select_input(session = session, inputId = "query_taxa",
                        choices = choices, selected = selected)
  }
  
  #' Update Choices for Traits (Taxonomy Module)
  #'
  #' Populates the \code{traits_to_predict} selectize input with the trait
  #' categories available for taxonomy-based prediction. When
  #' \code{poor_choices} is non-\code{NULL} and not \code{FALSE}, traits
  #' listed in \code{poor_traits_taxonomy} are dropped from the choice list.
  #' Used both at module load (with \code{poor_choices = NULL}) and when
  #' \code{input$hide_poor_traits} changes.
  #'
  #' @param session The Shiny session object. Defaults to the current reactive domain.
  #' @param poor_choices Value of \code{input$hide_poor_traits} (logical or
  #'   \code{NULL}). When \code{TRUE}, traits in
  #'   \code{poor_traits_taxonomy} are excluded from the choices.
  #'
  #' @return Invisibly \code{NULL}. Called for its side effect of updating
  #'   the \code{traits_to_predict} selectize input.
  #' @export
  update_traits_to_predict_taxonomy <- function(session = shiny::getDefaultReactiveDomain(),
                                         poor_choices = NULL) {
    # Get data
    database <- load_database()
    
    # Get choices for traits
    choices <- choices_traits_taxonomy
    
    if (!is.null(poor_choices) & !isFALSE(poor_choices)) {
      choices <- setdiff(choices, poor_traits_taxonomy)
    }
    
    selected <-  c(
                    "Type of metabolism (FAPROTAX2)", 
                    "Type of metabolism (Fermentation Explorer)", 
                    "Metabolites utilized (Fermentation Explorer)", 
                    "Metabolites produced (Fermentation Explorer)",
                    "Oxygen tolerance (BacDive)"
                   )
    
    # Update UI
    update_select_input(session = session, inputId = "traits_to_predict",
                        choices = choices, selected = selected)
  }
  
  #' Update Choices for Taxonomy System (Taxonomy Module)
  #'
  #' Populates the \code{system_taxonomy} selectize input with the
  #' available taxonomy systems (LPSN, GTDB, NCBI).
  #'
  #' @param session The Shiny session object. Defaults to the current reactive domain.
  #' @return Invisibly \code{NULL}. Called for its side effect of updating
  #'   the \code{system_taxonomy} selectize input.
  #' @export
  update_system_taxonomy_taxonomy <- function(session = shiny::getDefaultReactiveDomain()) {
    # Get choices
    choices <- choices_system_taxonomy
    
    # Update UI
    update_select_input(session = session, inputId = "system_taxonomy",
                        choices = choices)
  }
  
  #' Update Choices for Trait to Display (Taxonomy Module)
  #'
  #' Populates the \code{trait_to_display} picker input with the trait
  #' categories present in the predicted-traits results. Categories whose
  #' maximum probability falls below \code{threshold} are flagged as
  #' "trait not predicted" via \code{format_picker_choices}. Used both
  #' after results are computed and when \code{input$probability_threshold} changes.
  #'
  #' @param session The Shiny session object. Defaults to the current reactive domain.
  #' @param data The data used to build the choices.
  #' @param threshold Numeric probability threshold below which a trait category is considered unpredicted.
  #' @return Invisibly \code{NULL}. Called for its side effect of updating
  #'   the \code{trait_to_display} picker input. \code{req()} short-
  #'   circuits the helper if no results are available.
  #' @export
  update_trait_to_display_taxonomy <- function(session = shiny::getDefaultReactiveDomain(),
                                               data,
                                               threshold) {
    # Check required conditions
    req(!is.null(data))
    
    # Get choices
    all_traits  <- unique(data$`Trait category`)
    unpredicted <- get_unpredicted_choices(data, choices_col = "Trait category", 
                                           value_col = "Probability", threshold = threshold)
    fmt <- format_picker_choices(all_traits, unpredicted, label = "trait not predicted")
    
    # Update UI
    update_picker_input(session = session, inputId = "trait_to_display",
                        choices = fmt$choices,
                        choicesOpt = fmt$choicesOpt)
  }
  
  #' Update Choices for Organisms to Display (Taxonomy Module)
  #'
  #' Populates the \code{organism_to_display} picker input with one entry
  #' per query taxon, using \code{format_query_taxa_choices} to build the
  #' label/value mapping. Defaults the selection to the first query.
  #'
  #' @param session The Shiny session object. Defaults to the current reactive domain.
  #' @param data The data used to build the choices.
  #' @return Invisibly \code{NULL}. Called for its side effect of updating
  #'   the \code{organism_to_display} picker input. \code{req()} short-
  #'   circuits the helper if no query taxa are available.
  #' @export
  update_organism_to_display_taxonomy <- function(session = shiny::getDefaultReactiveDomain(),
                                                   data) {
    # Check required conditions
    req(!is.null(data) && nrow(data) > 0)
    
    # Get choices
    choices <- format_query_taxa_choices(data)
    selected <- choices[1]
    
    # Update UI
    update_picker_input(session = session, inputId  = "organism_to_display",
                        choices  = choices, selected = selected)
  }